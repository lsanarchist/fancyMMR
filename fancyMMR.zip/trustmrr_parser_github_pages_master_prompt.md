# Master prompt: build a public-sample parser + stats pipeline + GitHub Pages site

You are a senior data engineer, web scraper, and front-end data-visualization developer.

Your task is to build a **production-ready, reproducible research pipeline** that crawls **publicly accessible pages only**, extracts startup/revenue data, computes summary statistics, and publishes a static research site on **GitHub Pages**.

This project should be designed for a dataset similar to a visible public sample of startups with `Revenue (30d) >= $5,000`, but the code must be generic enough that the source site can be reconfigured.

## Product goal

Build a repository that:
1. Crawls a configurable set of public source pages.
2. Extracts startup rows and normalizes them into a clean dataset.
3. Computes research summaries and concentration metrics.
4. Renders publication-grade charts.
5. Generates a static site for GitHub Pages.
6. Rebuilds automatically with GitHub Actions.
7. Fails loudly when the source site changes.
8. Preserves legal and methodological caveats.

## Non-negotiable requirements

- Use **public pages only**.
- Respect `robots.txt`, polite rate limits, retries, caching, and source-site stability.
- No login, no API keys, no anti-bot circumvention, no headless browser unless strictly necessary.
- Prefer plain HTTP fetching first; add Playwright fallback only for pages that cannot be parsed statically.
- Every extracted record must keep `source_url` and `scraped_at`.
- The pipeline must be deterministic and reproducible.
- The output must be suitable for a public GitHub repo and GitHub Pages deployment.
- The site must look clean on desktop and mobile.
- Charts must avoid the previous “broken bubble chart” problem where one outlier crushes the rest of the scale.

## Tech stack

Use this stack unless there is a strong reason not to:
- **Python 3.12**
- `httpx` or `requests` for HTTP
- `beautifulsoup4` + `lxml` for parsing
- optional `playwright` only as fallback
- `pandas` + `numpy` for transforms
- `pydantic` for schemas
- `matplotlib` for exportable PNG/SVG charts
- static site built with either:
  - plain Jinja templates + generated HTML, or
  - an Eleventy/Astro/Vite static frontend consuming generated JSON
- GitHub Actions for scheduled rebuild + Pages deploy

Default to the simplest stack that is robust.

## Repository shape

Create a repo with this structure:

```text
.
├── .github/
│   └── workflows/
│       ├── build.yml
│       └── pages.yml
├── data/
│   ├── raw/
│   ├── interim/
│   ├── processed/
│   ├── snapshots/
│   ├── metrics.json
│   ├── visible_sample.csv
│   ├── category_summary.csv
│   ├── business_model_summary.csv
│   ├── gtm_model_summary.csv
│   ├── revenue_band_summary.csv
│   └── public_source_pages.csv
├── charts/
│   ├── category_share_map.png
│   ├── category_share_map.svg
│   ├── top_categories_revenue.png
│   ├── top_categories_revenue.svg
│   ├── category_over_index.png
│   ├── category_over_index.svg
│   ├── model_mix.png
│   ├── model_mix.svg
│   ├── distribution_and_concentration.png
│   └── distribution_and_concentration.svg
├── site/
│   ├── index.html
│   ├── methodology.html
│   ├── data.html
│   ├── assets/
│   │   ├── css/
│   │   ├── js/
│   │   └── img/
│   └── data/
│       ├── metrics.json
│       ├── visible_sample.json
│       ├── category_summary.json
│       ├── business_model_summary.json
│       ├── gtm_model_summary.json
│       └── revenue_band_summary.json
├── src/
│   ├── config.py
│   ├── schemas.py
│   ├── fetch.py
│   ├── parse.py
│   ├── normalize.py
│   ├── validate.py
│   ├── aggregate.py
│   ├── charts.py
│   ├── build_site.py
│   ├── build_all.py
│   └── utils.py
├── tests/
│   ├── test_parse.py
│   ├── test_normalize.py
│   ├── test_aggregate.py
│   └── fixtures/
├── docs/
│   ├── methodology.md
│   ├── data-notice.md
│   └── source-notes.md
├── README.md
├── CHANGELOG.md
├── LICENSE
├── requirements.txt
├── pyproject.toml
└── Makefile
```

## Data model

Create a normalized row-level dataset with these required columns:

- `name`
- `category`
- `revenue_30d`
- `source_url`
- `source_page_type`
- `scraped_at`
- `currency_raw`
- `revenue_raw`
- `notes`

Support these optional derived columns:
- `biz_model`
- `gtm_model`
- `location`
- `pricing_hint`
- `tags`

Create `pydantic` schemas for:
- raw row
- normalized startup row
- category summary row
- model summary row
- metrics object

## Parsing rules

The parser must be config-driven.

Implement:
- a source registry with seed URLs
- per-page parser strategies
- CSS selectors or XPath in config where possible
- fallback text parsing when structured HTML is missing
- robust currency parsing for `$5k`, `$19.0k`, `$1.2M`, `$993k`, etc.
- deduplication by canonical startup name + source URL
- canonical slug generation

If the site layout changes, the pipeline must:
- emit a clear error
- save the failing HTML snapshot
- write a structured validation report
- exit non-zero in CI

## Validation rules

Add strict validation:
- no nulls in required columns
- `revenue_30d` must be numeric and positive
- inclusion threshold configurable, default `5000`
- no rows below threshold in the final visible-sample export
- categories normalized to a stable vocabulary
- detect suspicious duplicates
- track row counts across stages

Generate:
- `validation_report.json`
- `pipeline_manifest.json`
- `source_coverage_report.json`

## Metrics and summaries

Compute at least these metrics:
- total visible startups
- total visible 30-day revenue
- median revenue
- p75, p90, p95 revenue
- top 1 / 5 / 10 / 20 revenue share
- startup share by category
- revenue share by category
- performance index = revenue share / startup share
- revenue bands
- revenue concentration curve
- Herfindahl-Hirschman Index on revenue concentration
- Gini coefficient of revenue concentration

Create these outputs:
- `visible_sample.csv`
- `visible_sample.json`
- `category_summary.csv`
- `business_model_summary.csv`
- `gtm_model_summary.csv`
- `revenue_band_summary.csv`
- `metrics.json`
- `public_source_pages.csv`

## Heuristic labeling

Implement optional heuristic labeling for:
- `biz_model`
- `gtm_model`

But treat them explicitly as analyst/heuristic fields, not first-party truth.

Rules:
- keep heuristics transparent and deterministic
- store the mapping logic in code
- allow manual overrides via a YAML or CSV mapping file
- document every override

## Chart requirements

Render publication-grade charts in both PNG and SVG.

Required charts:
1. `category_share_map`
   - do **not** use one overloaded bubble chart
   - instead render a **two-panel view**:
     - full view
     - zoom view excluding the dominant outlier category
   - dashed equality line
   - readable labels with collision handling
   - annotation note explaining why the zoom view exists

2. `top_categories_revenue`
   - horizontal bar chart
   - top 10 categories by visible revenue
   - labels with revenue and startup count

3. `category_over_index`
   - horizontal bar chart
   - show performance index
   - vertical reference line at `1.0`

4. `model_mix`
   - two side-by-side horizontal charts
   - business model mix
   - GTM model mix

5. `distribution_and_concentration`
   - left: revenue band distribution
   - right: cumulative revenue concentration curve
   - annotate top-10 revenue share

Style requirements:
- white background
- clean grid
- readable typography
- color-blind-safe palette
- no chartjunk
- exports must look good in README, GitHub Pages, and social preview images

## GitHub Pages site

Build a static site that includes:
- landing page with key stats
- methodology page
- data page with download links
- chart gallery
- notes on limitations
- last updated timestamp
- source notice / attribution / caveats

The homepage must have:
- hero summary
- 4–6 KPI cards
- main charts
- short narrative insights
- link to CSV/JSON downloads
- link to methodology

The site must support:
- dark-on-light design
- mobile responsiveness
- basic SEO metadata
- Open Graph image
- clean URLs if possible

## README requirements

Generate a strong `README.md` with:
- what the project is
- scope and limits
- methodology summary
- key takeaways
- chart previews
- repo structure
- rebuild instructions
- publishing note
- legal/data caveat

## GitHub Actions

Create workflows for:
1. `build.yml`
   - on push / pull_request
   - install dependencies
   - run tests
   - run full build
   - upload artifacts

2. `pages.yml`
   - on main branch push and scheduled cron
   - rebuild data and site
   - deploy `site/` to GitHub Pages

Requirements:
- cache dependencies
- fail on validation errors
- publish build artifacts
- include a scheduled refresh, e.g. weekly

## CLI and DX

Provide a small CLI or Makefile commands:
- `make fetch`
- `make parse`
- `make validate`
- `make aggregate`
- `make charts`
- `make site`
- `make all`
- `make test`

Also support:
- `python -m src.build_all`

## Testing

Add tests for:
- revenue parsing
- selector-based parsing
- malformed row handling
- normalization of categories
- aggregation math
- concentration metrics
- chart generation smoke test

Use HTML fixtures for parser tests.

## Production-quality expectations

This is not a throwaway notebook.

I expect:
- clean modular code
- typed Python where practical
- good function names
- small cohesive modules
- docstrings where helpful
- sensible logging
- explicit errors
- deterministic outputs
- no hidden manual steps

## What to optimize for

Optimize for:
1. reproducibility
2. reliability under source-page drift
3. clarity of methodology
4. public-repo presentation quality
5. GitHub Pages polish
6. maintainability for a solo operator

## What to avoid

Do not:
- build a giant full-stack app
- depend on a database unless truly needed
- over-engineer infra
- use fragile screenshot scraping as primary extraction
- hide caveats about coverage
- present heuristic labels as objective truth

## Deliverables

Return:
1. the complete repository tree
2. the core Python source files
3. the GitHub Actions workflows
4. the static site templates/assets
5. the parser config
6. the tests
7. a short explanation of architecture decisions
8. exact local run steps
9. exact GitHub Pages deployment steps
10. examples of expected CSV/JSON output

## Implementation order

Work in this order:
1. define schemas and config
2. implement fetch/cache layer
3. implement parser with tests
4. normalize and validate
5. aggregate metrics
6. generate charts
7. build static site
8. wire CI/CD
9. polish README/docs

## Extra details from prior research bundle

Assume the current research bundle already had outputs like:
- `visible_sample.csv`
- `category_summary.csv`
- `business_model_summary.csv`
- `gtm_model_summary.csv`
- `revenue_band_summary.csv`
- `metrics.json`
- charts such as `category_share_map`, `top_categories_revenue`, `category_over_index`, `model_mix`, and `distribution_and_concentration`

Also assume that one earlier chart was visually broken because a dominant outlier category compressed the rest of the plot. Your implementation must explicitly solve that problem in the production version.

## Final output format

Produce the answer in this format:

1. **Architecture overview**
2. **Repository tree**
3. **Key files with code**
4. **How the parser works**
5. **How the site build works**
6. **How GitHub Actions deploys Pages**
7. **How to run locally**
8. **Known limitations and caveats**

Do not stay high-level. Write the actual code and files.

# Stable queue prompt

Continue the implementation using the repo control plane in `AGENT.md` and `.agent/*`. Read `AGENT.md`, `.agent/RUNBOOK.md`, `.agent/STATE.yaml`, `.agent/TASK_QUEUE.yaml`, `.agent/HANDOFF.md`, `.agent/DECISIONS.md`, and `.agent/TEST_GATES.md`. If `STATE.yaml` has a current in-progress task, continue it. Otherwise pick the highest-priority task whose status is `todo` and whose dependencies are done. Implement one coherent task end-to-end, run the relevant verification, update the control-plane files, and stop. Do not ask for next steps if there is any unblocked `todo` task.

# Stricter variant

Continue the implementation using the repo control plane in `AGENT.md` and `.agent/*`. Read `AGENT.md`, `.agent/RUNBOOK.md`, `.agent/STATE.yaml`, `.agent/TASK_QUEUE.yaml`, `.agent/HANDOFF.md`, `.agent/DECISIONS.md`, and `.agent/TEST_GATES.md`. If `STATE.yaml` has a current in-progress task, continue it. Otherwise pick the highest-priority task whose status is `todo` and whose dependencies are done. Implement exactly one top-level task end-to-end, or one tightly coupled pair only if verification overlap makes that cheaper. Run the relevant verification, update `STATE.yaml`, `TASK_QUEUE.yaml`, `HANDOFF.md`, `WORKLOG.md`, and `DECISIONS.md` if needed, and stop. Do not ask the user what to do next if any unblocked `todo` task remains.

# Universal operating rules

- Use the task queue, not intuition.
- Keep first runs small and verifiable.
- Prefer minimal coherent slices over broad rewrites.
- Keep the repo buildable and testable after each run.
- Keep exact verification commands in `WORKLOG.md`.
- Keep architecture assumptions in `DECISIONS.md`.
- Keep `STATE.yaml` and `TASK_QUEUE.yaml` synchronized with repo reality.
- Never weaken the queue system into a loose note-taking workflow.
- The queue must remain the source of truth for what to do next.

# Bootstrap behavior when no control plane exists yet

1. Inspect the repo and infer its actual project shape from code, docs, tests, scripts, and file layout.
2. Create `AGENT.md` with concrete project-specific guidance.
3. Create the `.agent` directory and all required files.
4. Build an initial phased `TASK_QUEUE.yaml` from current repo reality.
5. Seed `STATE.yaml` with an honest repo snapshot.
6. Seed `HANDOFF.md` with current state and sensible next work.
7. Seed `WORKLOG.md` with a bootstrap entry.
8. Create `QUEUE_PROMPT.md`.
9. Then execute the first real task if doing so is coherent and verifiable in the same run.

# How to build the initial task queue

- Prefer early bootstrap tasks for build, configuration, local run, health checks, and basic tests.
- Then add core domain and runtime tasks.
- Then add recovery, operator tooling, and automation.
- Make dependencies explicit.
- Include deliverables and verify commands on every task.
- Use phases and priorities to force deterministic selection.

# How to operate on every future run

1. Read the control plane.
2. Reconcile state vs actual repo.
3. Continue the current in-progress task if valid.
4. Otherwise pick the next deterministic task.
5. Implement one coherent task end-to-end.
6. Run verification.
7. Update the control plane.
8. Stop cleanly.

# Commit behavior

- If the environment allows commits and the project expects them, create one clean commit after a verified run.
- If commits are not possible or not wanted, stop cleanly after updating the control plane.

# Success condition

Leave the repo in a state where the same stable queue prompt can be submitted again and the next run will continue correctly without fresh human task management.

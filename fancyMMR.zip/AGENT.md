# Project Contract

## Project goal

Turn this repo from a packaged visible-sample research bundle into a reproducible public-page parser, analytics pipeline, and GitHub Pages publication flow for TrustMRR-like startup revenue research.

The current repo already contains:

- processed research data in `data/`
- publication charts in `charts/`
- methodology and publication caveats in `docs/`, `DATA-NOTICE.md`, and `README.md`
- a single rebuild script in `src/build_artifacts.py`

The target repo must grow beyond that seed bundle into a source-driven pipeline:

`public sources -> fetch -> parse -> normalize -> validate -> aggregate -> charts -> site -> CI/pages`

## Project operating model

This repo runs in autonomous queue mode.

- `AGENT.md` is the master contract.
- `.agent/TASK_QUEUE.yaml` is the source of truth for what to do next.
- `.agent/STATE.yaml` records the current repo snapshot.
- `.agent/RUNBOOK.md` defines the exact loop every run must follow.
- `.agent/HANDOFF.md` is the concise bridge to the next run.
- `.agent/WORKLOG.md` and `.agent/DECISIONS.md` are append-only history.

Repeated identical prompts should produce deterministic progress from repo state alone, not from fresh operator task management.

## Architecture overview

### Current baseline architecture

- `src/build_artifacts.py` is a monolithic Python script.
- It reads `data/visible_sample.csv`.
- It validates the required visible-sample columns and the `$5,000` threshold.
- It computes category, business-model, GTM-model, and revenue-band summaries.
- It writes summary CSVs plus `data/metrics.json`.
- It renders publication charts to `charts/*.png` and `charts/*.svg`.
- It rewrites the root `README.md` from computed metrics.

### Current gaps

- No fetch layer exists yet.
- No parser or normalization pipeline exists yet.
- No raw/interim/snapshots directory structure exists yet.
- No `site/` output exists yet.
- No tests or CI workflows exist yet.
- No modular source package exists yet.
- The imported bundle is not fully reproducible today: re-running `python src/build_artifacts.py` removes `gini_coefficient` from `data/metrics.json`.

### Target architecture

- `src/config.py`: source registry, thresholds, paths, rate limits, parser config
- `src/schemas.py`: pydantic schemas for raw rows, normalized rows, summaries, metrics
- `src/fetch.py`: polite public-page fetching with caching and loud failure behavior
- `src/parse.py`: config-driven HTML extraction with per-page strategies
- `src/normalize.py`: revenue parsing, canonical naming, dedupe, heuristic field derivation
- `src/validate.py`: row-level and pipeline-level validation reports
- `src/aggregate.py`: summaries and concentration metrics
- `src/charts.py`: publication chart rendering
- `src/build_site.py`: static site generation
- `src/build_all.py`: end-to-end entrypoint

## Explicit non-goals

- No private, authenticated, or anti-bot-circumventing data access
- No claim of platform-wide coverage or full database export
- No silent best-effort parsing when the source layout changes
- No broad UI rewrite that drops the research framing
- No replacing deterministic build artifacts with manual spreadsheet steps

## Hard constraints and truths to preserve

- Preserve the "visible public sample" framing in docs and site copy.
- Preserve methodology and legal caveats from `README.md`, `docs/methodology.md`, and `DATA-NOTICE.md`.
- Use public pages only and keep crawling polite.
- Every extracted record must keep `source_url` and `scraped_at`.
- `biz_model` and `gtm_model` are heuristic analyst fields, not first-party truth.
- Fail loudly when source HTML changes; save enough debugging material to understand why.
- Keep the repo rebuildable from checked-in code and documented commands.
- Keep the current chart set conceptually intact, including the two-panel category share map that avoids the outlier-crushed bubble chart problem.
- Keep new Python code compatible with Python 3.12 even if local runs use Python 3.13.

## Coding rules

- Prefer minimal coherent slices over large refactors.
- Keep behavior deterministic and file outputs stable where possible.
- Split large modules before adding new surface area to them.
- Add targeted tests or fixtures alongside parser, normalization, aggregation, and validation logic.
- Prefer fixture-backed parsing tests before any live-source smoke checks.
- Keep configuration explicit; avoid hard-coding source-specific assumptions deep inside parsing logic.
- Do not weaken caveats or provenance fields for the sake of convenience.

## Verification policy summary

- The current mandatory baseline gate is `python src/build_artifacts.py`.
- Every task must also run the narrowest meaningful verification for the files it changed.
- Verification expectations by task type live in `.agent/TEST_GATES.md`.
- A task is not `done` if its defined verification fails.

## Milestone plan

### Phase 0 - Baseline import and reproducibility

- Import the seed bundle into normal repo files.
- Repair the current metrics reproducibility gap.
- Add a local test harness for future safe refactors.

### Phase 1 - Modular analytics foundation

- Split the monolith into modular pipeline files.
- Add validation manifests and failure reports.
- Add a static site generator that publishes the current processed research outputs.

### Phase 2 - Public-page pipeline

- Add config-driven source registry and polite fetching.
- Parse and normalize public source pages into raw and processed datasets.
- Add deterministic heuristic overrides and dedupe logic.

### Phase 3 - Automation and publication

- Add GitHub Actions for rebuilds and Pages deployment.
- Finalize repo docs, release process, and publication polish.

## Acceptance criteria

- A fresh clone can rebuild the visible sample outputs from public source pages with documented commands.
- The pipeline produces validated processed datasets, charts, and static site artifacts.
- Layout changes in the source site fail loudly with preserved debug artifacts.
- The public site and docs preserve visible-sample caveats and provenance.
- GitHub Actions can rebuild and publish the site automatically.
- Re-running the stable queue prompt advances exactly one deterministic task and updates the control plane without human task picking.

## Autonomous operating model

Every autonomous run must:

1. Read `AGENT.md` plus the control-plane files in the order defined by `.agent/RUNBOOK.md`.
2. Reconcile actual repo state with `.agent/STATE.yaml` and `.agent/TASK_QUEUE.yaml`.
3. Continue `STATE.yaml.current_task_id` if it is still a valid `in_progress` task.
4. Otherwise pick the next eligible task from `.agent/TASK_QUEUE.yaml`.
5. Implement one coherent task end-to-end, or a tightly coupled second task only when the runbook allows it.
6. Run the relevant verification.
7. Update `.agent/STATE.yaml`, `.agent/TASK_QUEUE.yaml`, `.agent/HANDOFF.md`, `.agent/WORKLOG.md`, and `.agent/DECISIONS.md` if needed.
8. Stop cleanly so the same prompt can resume from repo state next run.

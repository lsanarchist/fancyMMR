# Queue Runbook

## Required read order at the beginning of every run

1. `AGENT.md`
2. `.agent/STATE.yaml`
3. `.agent/TASK_QUEUE.yaml`
4. `.agent/HANDOFF.md`
5. `.agent/DECISIONS.md`
6. `.agent/TEST_GATES.md`
7. `.agent/WORKLOG.md` (tail only if it is large)

## Selection behavior

- If `STATE.yaml.current_task_id` exists and the corresponding task is `in_progress`, continue it first.
- Otherwise pick the next task deterministically.
- Eligible task = `status == todo` AND all `depends_on` tasks are `done` AND the task is not explicitly blocked by an active blocker in `STATE.yaml`.
- Tie-breaker order = higher priority, lower phase, lexical id.

## Bundling policy

- Default: finish exactly one top-level task per run.
- A second task is allowed only if it is tightly coupled, trivial compared with the first, already overlaps in touched files, and is covered by the same verification.
- If in doubt, stop after one task.

## Pre-change behavior

- Inspect the current repo tree.
- Confirm whether target files already exist.
- Reconcile any mismatch between repo reality and `STATE.yaml`.
- If the queue is stale, update it before coding.

## Execution style

- Prefer minimal coherent slices over giant refactors.
- Preserve forward momentum for the next run.
- Do not postpone basic testability.
- If a task is too large, split it into smaller tasks in `TASK_QUEUE.yaml` before coding.

## Verification rule

- Run the narrowest meaningful verification for the task plus any mandatory global gates from `TEST_GATES.md`.
- Record commands and outcomes in `WORKLOG.md`.

## Control-plane update rule after coding

- Mark the task `done` in `TASK_QUEUE.yaml` if completed.
- If incomplete, keep it `in_progress` and record the exact remainder.
- Update `STATE.yaml` with `current_task_id`, `last_completed_task_id`, `current_phase`, `blockers`, and recently touched files.
- Update `HANDOFF.md` with what changed, what is most sensible next, and exact verify commands if special.
- Append a `WORKLOG.md` entry.
- Append a `DECISIONS.md` entry if architecture assumptions changed.

## Blocker handling

- Mark blocked tasks as `blocked` in `TASK_QUEUE.yaml`.
- Add concise blockers to `STATE.yaml`.
- Explain unblock conditions in `HANDOFF.md`.
- Pick the next unblocked task if one exists.
- Do not ask the operator for next steps unless the repo is truly blocked and no useful unblocked task remains.

## Branch policy

- One autonomous worker per branch or per worktree.
- Never allow two active runs writing the same branch.
- If parallel workers exist, each must own a disjoint task set or a dedicated branch/worktree.
- Before merge, refresh the control-plane files from the target branch and resolve conflicts carefully.

## Good run definition

A good run:

- leaves the repo better than before
- finishes one coherent task or tightly-coupled pair
- verifies the result
- updates the control plane so the same prompt can continue without human help

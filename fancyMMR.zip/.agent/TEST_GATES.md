# Test Gates

## General rules

- Do not mark a task `done` if its defined verification did not pass.
- If verification fails, either fix it in the same run or leave the task `in_progress` with the exact remainder documented in `HANDOFF.md`.
- Record exact verification commands and high-level outcomes in `WORKLOG.md`.

## Mandatory current global gate

Any task that changes `src/build_artifacts.py`, generated data under `data/`, or generated charts under `charts/` must run:

- `python src/build_artifacts.py`

## Build-graph or wiring changes

Use this when changing entrypoints, project config, module wiring, output paths, or the site-generation/build graph.

- Run the smallest end-to-end entrypoint affected by the change.
- For the current repo, keep `python src/build_artifacts.py` green.
- If a new entrypoint is added, add at least one command-level smoke verification for it.

## Pure logic changes

Use this for deterministic computations such as revenue parsing, aggregation, ranking, concentration metrics, or label heuristics.

- Run targeted unit tests when they exist.
- Add a focused assertion-based smoke check if no unit test exists yet.
- Also run any impacted build smoke, especially `python src/build_artifacts.py` for current aggregation/chart logic.

## SQL / migration changes

No SQL layer exists today. If one is introduced later:

- Verify upgrade and rollback on an ephemeral local database.
- Verify schema expectations in tests.
- Do not mark the task `done` without migration verification.

## External adapter changes

Use this for source registry, HTTP fetching, HTML parsing, caching, robots handling, retries, or snapshot capture.

- Prefer fixture-backed tests first.
- If a live smoke check is necessary, keep it narrow, polite, and deterministic.
- Save failing HTML snapshots and surface the failure clearly.
- Do not mark the task `done` if the adapter can fail silently.

## Replay / renderer changes

This repo already renders research charts and will later render a static site.

- Rebuild the affected outputs.
- Confirm the expected files are regenerated.
- For chart changes, visually broken scaling or unreadable labels count as verification failures even if the command exits zero.
- For site changes, verify key pages exist and still carry methodology caveats.

## Failure handling rules

- If a generator command exits non-zero, keep the task `in_progress` or `blocked`.
- If generated outputs drift unexpectedly, record the exact drift and either fix it in the same run or queue a follow-up task immediately.
- Never suppress or hand-wave a reproducibility gap.

# Current state

The seed release has been imported into the repo root and the current bundle rebuild command works locally. The repo now has real `charts/`, `data/`, `docs/`, and `src/` files to evolve from, but it is still only a packaged visible-sample research bundle, not the full public-page pipeline requested by the prompts.

# What changed this run

- Imported the contents of `trustmrr_visible_sample_github_release.zip` into the repo root
- Replaced the placeholder root `README.md` with the bundled visible-sample README
- Reconciled `.gitignore` so prompt files and the seed zip stay untracked while repo markdown stays trackable
- Bootstrapped `AGENT.md` and the full `.agent/` control plane
- Verified `python src/build_artifacts.py` runs successfully

# Current focus

`P0-T002` - restore metrics contract reproducibility in `src/build_artifacts.py`.

# Recommended next tasks

- `P0-T002` to add back `gini_coefficient` and confirm the metrics contract matches the shipped seed outputs
- `P0-T003` to add pytest-based smoke coverage before the monolith is split

# Verification from this run

- `python -c 'import pandas, numpy, matplotlib; print("deps-ok")'`
- `python src/build_artifacts.py`
- `diff -u <(unzip -p trustmrr_visible_sample_github_release.zip trustmrr_visible_sample_github_release/data/metrics.json) data/metrics.json`

# Notes for the next run

- The only known drift from the imported seed bundle after a local rebuild is that `data/metrics.json` loses `gini_coefficient`.
- `README.md` reproduced exactly after the rebuild.
- There is still no fetch layer, parser, site generator, tests, or CI workflow in the repo.

# Immediate constraints

- Preserve the visible-public-sample framing and methodology caveats
- Use public pages only when fetch/parser work begins
- Keep Python changes compatible with Python 3.12

# Repo truths to preserve

- `src/build_artifacts.py` is the current baseline generator
- `data/visible_sample.csv` is currently the seed input, not the final source-of-truth pipeline output
- Prompt files are local operator inputs, not queue state

# Decisions

## D-001 - Use the extracted seed release as the current implementation baseline
- Date: 2026-03-26
- Context: The repo started as a minimal git history plus a bundled release zip and operator prompt files.
- Decision: Extract the `trustmrr_visible_sample_github_release` bundle into the repo root and treat those files as the current baseline implementation.
- Consequences: Future work can modify normal repo files instead of operating on a zip artifact; the zip can remain a local bootstrap input rather than tracked source.

## D-002 - Preserve the visible-sample research framing as a hard product constraint
- Date: 2026-03-26
- Context: The imported docs and prompts consistently describe this work as a source-derived visible public sample, not a platform export.
- Decision: Keep methodology caveats, provenance fields, and public-source-only constraints throughout the parser, analytics, and site work.
- Consequences: Features that imply private access, hidden-source coverage, or silent caveat removal are out of scope.

## D-003 - The queue files, not the prompt files, define what happens next
- Date: 2026-03-26
- Context: The repo needs repeated identical prompts to continue deterministically without human task management.
- Decision: `STATE.yaml` and `TASK_QUEUE.yaml` are the authoritative task-selection mechanism; prompt files are operator-local inputs only.
- Consequences: Every meaningful run must update queue state, handoff, and worklog before stopping.

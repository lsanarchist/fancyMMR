# Control Plane

This directory is the repo-local autonomous queue control plane.

## File roles

- `STATE.yaml` - current snapshot of repo truth
- `TASK_QUEUE.yaml` - prioritized task list with dependencies
- `HANDOFF.md` - short human-readable current context
- `DECISIONS.md` - append-only ADR-style decision log
- `WORKLOG.md` - append-only execution log
- `TEST_GATES.md` - verification policy by task type
- `RUNBOOK.md` - exact loop the agent must follow every run

## Update rule

After every meaningful coding run, update at least:

- `STATE.yaml`
- `TASK_QUEUE.yaml`
- `HANDOFF.md`
- `WORKLOG.md`

If a durable architectural or process assumption changed, append `DECISIONS.md` too.

## Selection rule

- Continue `STATE.yaml.current_task_id` first if it still exists in `TASK_QUEUE.yaml` and is `in_progress`.
- Otherwise pick the highest-priority `todo` task whose dependencies are all `done` and that is not blocked by an active blocker in `STATE.yaml`.
- Deterministic tie-breaker: higher priority, lower phase, lexical id.
